/* Package declaration */
package com.examly.springapp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.SupportAgent;
import com.examly.springapp.service.SupportAgentServiceImpl;

/**
 * @author SRIVANI 10828911
 * Controller class for handling support agent-related operations.
 * 
 * Annotated with `@RestController` to indicate it's a Spring REST controller.
 */
@RestController
public class SupportAgentController {

    /**
     * Injecting SupportAgentServiceImpl dependency.
     * Annotated with `@Autowired` to inject the `SupportAgentServiceImpl` bean.
     */
    @Autowired 
    private SupportAgentServiceImpl supportAgentServiceImpl;

    /**
     * Endpoint for creating a support agent.
     * Handles POST requests to `/api/supportAgent`.
     * 
     * @param supportAgent the support agent data received from the request body.
     * @return a ResponseEntity containing the created support agent and HTTP status 201 (Created).
     */
    @PostMapping("/api/supportAgent")
    public ResponseEntity<SupportAgent> addSupportAgent(@RequestBody SupportAgent supportAgent) {
        /* Logging the received support agent data */
        System.out.println("Received support agent data for creation: " + supportAgent);
        
        /* Calling addSupportAgent method from supportAgentServiceImpl to create a new support agent */
        SupportAgent createdSupportAgent = supportAgentServiceImpl.addSupportAgent(supportAgent);
        
        /* Logging the created support agent data */
        System.out.println("Created support agent data: " + createdSupportAgent);
        
        /* Returning a 201 Created response with the created support agent */
        return ResponseEntity.status(201).body(createdSupportAgent);
    }

    /**
     * Endpoint for retrieving all support agents.
     * Handles GET requests to `/api/supportAgent`.
     * 
     * @return a ResponseEntity containing the list of all support agents and HTTP status 200 (OK).
     *         or HTTP status 204 (No Content) if no support agents are found.
     */
    @GetMapping("/api/supportAgent")
    public ResponseEntity<List<SupportAgent>> getAllSupportAgents() {
        /* Calling getAllSupportAgents method from supportAgentServiceImpl to retrieve all support agents */
        List<SupportAgent> supportAgents = supportAgentServiceImpl.getAllSupportAgents();
        
        /* Logging the retrieved support agent list */
        // System.out.println("Retrieved all support agents: " + supportAgents);
        
        if (supportAgents.isEmpty()) {
            /* Returning a 204 No Content response if no support agents are found */
            return ResponseEntity.status(204).build();
        }
        /* Returning a 200 OK response with the list of all support agents */
        return ResponseEntity.status(200).body(supportAgents);
    }

    /**
     * Endpoint for retrieving a support agent by ID.
     * Handles GET requests to `/api/supportAgent/{agentId}`.
     * 
     * @param agentId the ID of the support agent to retrieve.
     * @return a ResponseEntity containing the retrieved support agent and HTTP status 200 (OK) if found,
     *         or HTTP status 404 (Not Found) if not found.
     */
    @GetMapping("/api/supportAgent/{agentId}")
    public ResponseEntity<SupportAgent> getSupportAgent(@PathVariable Long agentId) {
        /* Logging the received support agent ID */
        System.out.println("Received support agent ID for retrieval: " + agentId);
        
        /* Calling getSupportAgentById method from supportAgentServiceImpl to retrieve the support agent */
        Optional<SupportAgent> supportAgent = supportAgentServiceImpl.getSupportAgentById(agentId);
        
        /* Logging the retrieved support agent data */
        System.out.println("Retrieved support agent data: " + supportAgent);
        
        if (supportAgent.isPresent()) {
            /* Returning a 200 OK response with the retrieved support agent */
            return ResponseEntity.status(200).body(supportAgent.get());
        } else {
            /* Returning a 404 Not Found response if support agent is not found */
            return ResponseEntity.status(404).build();
        }
    }

    /**
     * Endpoint for updating a support agent by ID.
     * Handles PUT requests to `/api/supportAgent/{agentId}`.
     * 
     * @param agentId the ID of the support agent to update.
     * @param supportAgent the updated support agent data received from the request body.
     * @return a ResponseEntity containing the updated support agent and HTTP status 200 (OK) if found,
     *         or HTTP status 404 (Not Found) if not found.
     */
    @PutMapping("/api/supportAgent/{agentId}")
    public ResponseEntity<SupportAgent> updateSupportAgent(@PathVariable Long agentId, @RequestBody SupportAgent supportAgent) {
        /* Logging the received support agent data for update */
        System.out.println("Received support agent data for update: " + supportAgent);
        
        /* Calling updateSupportAgent method from supportAgentServiceImpl to update the support agent */
        supportAgent = supportAgentServiceImpl.updateSupportAgent(agentId, supportAgent);
        
        /* Logging the updated support agent data */
        System.out.println("Updated support agent data: " + supportAgent);
        
        if (supportAgent != null) {
            /* Returning a 200 OK response with the updated support agent */
            return ResponseEntity.status(200).body(supportAgent);
        } else {
            /* Returning a 404 Not Found response if support agent is not found */
            return ResponseEntity.status(404).build();
        }
    }

    /**
     * Endpoint for deleting a support agent by ID.
     * Handles DELETE requests to `/api/supportAgent/{agentId}`.
     * 
     * @param agentId the ID of the support agent to delete.
     * @return a ResponseEntity containing the deleted support agent and HTTP status 200 (OK).
     */
    @DeleteMapping("/api/supportAgent/{agentId}")
    public ResponseEntity<SupportAgent> deleteSupportAgent(@PathVariable Long agentId) {
        /* Logging the received support agent ID for deletion */
        System.out.println("Received support agent ID for deletion: " + agentId);
        
        /* Calling deleteSupportAgent method from supportAgentServiceImpl to delete the support agent */
        SupportAgent supportAgent = supportAgentServiceImpl.deleteSupportAgent(agentId);
        
        /* Logging the deleted support agent data */
        System.out.println("Deleted support agent data: " + supportAgent);
        
        /* Returning a 200 OK response with the deleted support agent */
        return ResponseEntity.status(200).body(supportAgent);
    }
}
