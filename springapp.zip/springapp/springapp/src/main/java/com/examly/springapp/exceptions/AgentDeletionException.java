package com.examly.springapp.exceptions;

/**
 * This exception is thrown when an agent cannot be deleted.
 */
public class AgentDeletionException extends RuntimeException {
    
    /**
     * Constructs a new exception with {@code null} as its detail message.
     */
    public AgentDeletionException() {
        super();
    }

        /**
     * Constructs a new exception with the specified detail message.
     *
     * @param message the detail message.
     */
    public AgentDeletionException(String message) {
        super(message);
    }
}
