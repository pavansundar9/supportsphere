package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;
import com.examly.springapp.model.SupportAgent;

/**
 * @author Sravani
 * Service interface for managing support agent-related operations.
 * 
 * Defines the support agent interface for the `SupportAgentServiceImpl` class, providing methods for support agent CRUD operations.
 */
public interface SupportAgentService {

    /**
     * Adds a new support agent to the system.
     *
     * @param supportAgent the `SupportAgent` entity to be added.
     * @return the added `SupportAgent` entity.
     */
    SupportAgent addSupportAgent(SupportAgent supportAgent);

    /**
     * Retrieves a support agent by their unique ID.
     *
     * @param agentId the ID of the support agent to retrieve.
     * @return an `Optional` containing the `SupportAgent` entity if found, or `Optional.empty()` otherwise.
     */
    Optional<SupportAgent> getSupportAgentById(Long agentId);

    /**
     * Retrieves all support agents from the system.
     *
     * @return a list of all `SupportAgent` entities.
     */
    List<SupportAgent> getAllSupportAgents();

    /**
     * Updates an existing support agent by ID.
     *
     * @param agentId the ID of the support agent to update.
     * @param supportAgent the updated `SupportAgent` entity details.
     * @return the updated `SupportAgent` entity if found, or throws an exception if not found.
     */
    SupportAgent updateSupportAgent(Long agentId, SupportAgent supportAgent);

    /**
     * Deletes a support agent by their unique ID.
     *
     * @param agentId the ID of the support agent to delete.
     * @return the deleted `SupportAgent` entity.
     */
    SupportAgent deleteSupportAgent(Long agentId);
}
