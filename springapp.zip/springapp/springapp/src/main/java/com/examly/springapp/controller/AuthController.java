/* Package declaration */
package com.examly.springapp.controller; 

/* Importing Autowired for dependency injection */
import org.springframework.beans.factory.annotation.Autowired; 

/* Importing ResponseEntity to handle HTTP responses */
import org.springframework.http.ResponseEntity; 

/* Importing PostMapping to handle POST requests */
import org.springframework.web.bind.annotation.PostMapping; 

/* Importing RequestBody to extract data from the request body */
import org.springframework.web.bind.annotation.RequestBody; 

/* Importing RequestMapping to map requests to the controller */
import org.springframework.web.bind.annotation.RequestMapping; 

/* Importing RestController to define a REST controller */
import org.springframework.web.bind.annotation.RestController; 

/* Importing JwtUtils for JWT token generation */
import com.examly.springapp.config.JwtUtils; 

/* Importing LoginDTO for login data transfer object */
import com.examly.springapp.model.LoginDTO; 

/* Importing User model */
import com.examly.springapp.model.User; 

/* Importing UserServiceImpl for user service implementation */
import com.examly.springapp.service.UserServiceImpl; 

/**
 * @author PAVAN SUNDAR 10828911
 * Controller class for handling authentication-related operations.
 * 
 * Annotated with `@RestController` to indicate it's a Spring REST controller.
 * Maps requests to `/api` to this controller.
 */
@RestController 
@RequestMapping("/api") 
public class AuthController { 

    /**
     * Injecting UserServiceImpl dependency.
     * Annotated with `@Autowired` to inject the `UserServiceImpl` bean.
     */
    @Autowired 
    private UserServiceImpl userServiceImpl; 

    /**
     * Injecting JwtUtils dependency.
     * Annotated with `@Autowired` to inject the `JwtUtils` bean.
     */
    @Autowired 
    private JwtUtils jwtUtils; 

    /**
     * Endpoint for user registration.
     * Handles POST requests to `/register`.
     * 
     * @param user the user data received from the request body.
     * @return a ResponseEntity containing the created user and HTTP status 201 (Created).
     */
    @PostMapping("/register") 
    public ResponseEntity<User> createUser(@RequestBody User user) { 
        /* Logging the received user data */
        System.out.println("Received user data for registration: " + user);
        
        /* Calling createUser method from userServiceImpl to create a new user */
        User createdUser = userServiceImpl.createUser(user); 
        
        /* Logging the created user data */
        System.out.println("Created user data: " + createdUser);
        
        /* Returning a 201 Created response with the created user */
        return ResponseEntity.status(201).body(createdUser); 
    } 

    /**
     * Endpoint for user login.
     * Handles POST requests to `/login`.
     * 
     * @param user the login data received from the request body.
     * @return a ResponseEntity containing the login data and HTTP status 201 (Created).
     */
    @PostMapping("/login") 
    public ResponseEntity<LoginDTO> loginUser(@RequestBody User user) { 
        
        /* Calling loginUser method from userServiceImpl to authenticate the user */
        User authenticatedUser = userServiceImpl.loginUser(user); 

        /* Ensure the JWT token includes the user's role */
        String token = jwtUtils.generateToken(authenticatedUser.getEmail(), authenticatedUser.getUserRole()); 
        
        /* Creating a new LoginDTO object with the token, username, role, and user ID */
        LoginDTO response = new LoginDTO(token, authenticatedUser.getUsername(), authenticatedUser.getUserRole(), authenticatedUser.getUserId()); 
        
        /* Returning a 201 Created response with the login data */
        return ResponseEntity.status(201).body(response); 
    } 
}
