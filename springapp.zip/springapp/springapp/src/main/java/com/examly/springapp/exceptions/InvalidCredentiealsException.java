/* Package declaration */
package com.examly.springapp.exceptions;

/* Defining the InvalidCredentiealsException class that extends RuntimeException */
public class InvalidCredentiealsException extends RuntimeException { 

    /* Constructor that takes a message and passes it to the superclass constructor */
    public InvalidCredentiealsException(String msg) { 
        /* Calling the superclass constructor with the message */
        super(msg); 
    } 
} 
