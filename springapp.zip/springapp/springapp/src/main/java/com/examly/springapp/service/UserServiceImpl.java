package com.examly.springapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.examly.springapp.exceptions.EntityNotFoundException;
import com.examly.springapp.exceptions.InvalidCredentiealsException;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.UserRepo;

/**
 * @author  Pavan
 * @class UserServiceImpl
 * Service implementation for managing user-related operations.
 * 
 * Annotated with `@Service` to indicate it's a Spring service class.
 * Implements the `UserService` interface to provide specific business logic.
 */
@Service
public class UserServiceImpl implements UserService {

    private static final String USER_NOT_FOUND = "A user with this email already exists";
    private static final String INVALID_CREDENTIALS = "Invalid user name or password.";

    /**
     * Repository for managing `User` entity data access.
     * Annotated with `@Autowired` to inject the `UserRepo` bean.
     */
    @Autowired
    private UserRepo userRepo;

    /**
     * Password encoder for hashing passwords.
     * Annotated with `@Autowired` to inject the `PasswordEncoder` bean.
     */
    @Autowired
    private PasswordEncoder passwordEncoder;

    /**
     * Creates a new user in the system.
     *
     * @param user The user entity to be created.
     * @return The created user entity.
     * @throws EntityNotFoundException if a user with the same username or email already exists.
     */
    @Override
    public User createUser(User user) {
        if (userRepo.findByUsername(user.getUsername()).isPresent() || userRepo.findByEmail(user.getEmail()).isPresent()) {
            throw new EntityNotFoundException(USER_NOT_FOUND);
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepo.save(user);
    }

    /**
     * Logs in a user to the system.
     *
     * @param user The user entity with login credentials.
     * @return The user entity if login is successful.
     * @throws InvalidCredentiealsException if the username or password is incorrect.
     */
    @Override
    public User loginUser(User user) {
        User existingUser = userRepo.findByEmail(user.getEmail())
                .orElseThrow(() -> new EntityNotFoundException("User not found, please register"));

        if (!passwordEncoder.matches(user.getPassword(), existingUser.getPassword())) {
            throw new InvalidCredentiealsException(INVALID_CREDENTIALS);
        }
        return existingUser;
    }

    /**
     * Retrieves a user by their unique ID.
     *
     * @param userId The ID of the user to retrieve.
     * @return The user entity if found, or null otherwise.
     */
    public User getUserById(Long userId) {
        User existingUser = userRepo.findById(userId).orElse(null);
        if (existingUser != null) {
            existingUser.setPassword(null);
        }
        return existingUser;
    }

    /**
     * Retrieves a user by their username.
     *
     * @param username The username of the user to retrieve.
     * @return The user entity if found, or null otherwise.
     */
    public User getByUserName(String username) {
        return userRepo.findByUsername(username).orElse(null);
    }
}
