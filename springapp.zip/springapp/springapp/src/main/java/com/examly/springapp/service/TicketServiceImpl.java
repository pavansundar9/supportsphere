package com.examly.springapp.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.exceptions.DuplicateTicketException;
import com.examly.springapp.exceptions.EntityNotFoundException;
import com.examly.springapp.exceptions.TicketDeletionException;
import com.examly.springapp.model.SupportAgent;
import com.examly.springapp.model.Ticket;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.TicketRepo;

/**
 * @author Suleman
 * @class TicketServiceImpl
 * Service implementation for managing ticket-related operations.
 * 
 * Annotated with `@Service` to indicate it's a Spring service class.
 * Implements the `TicketService` interface to provide specific business logic.
 */
@Service
public class TicketServiceImpl implements TicketService {

    /**
     * Repository for managing `Ticket` entity data access.
     * Annotated with `@Autowired` to inject the `TicketRepo` bean.
     */
    @Autowired
    private TicketRepo ticketRepo;

    /**
     * Service for managing user-related operations.
     * Annotated with `@Autowired` to inject the `UserServiceImpl` bean.
     */
    @Autowired
    private UserServiceImpl userServiceImpl;

    /**
     * Service for managing support agent-related operations.
     * Annotated with `@Autowired` to inject the `SupportAgentServiceImpl` bean.
     */
    @Autowired
    private SupportAgentServiceImpl supportAgentServiceImpl;

    /**
     * Adds a new ticket to the system.
     *
     * @param ticket The ticket entity to be added.
     * @return The added ticket entity.
     * @throws DuplicateTicketException if a ticket with the same title and issue details already exists.
     */
    @Override
    public Ticket addTicket(Ticket ticket) {
        if (ticketRepo.existsByTitleAndDescription(ticket.getTitle(), ticket.getDescription())) {
            throw new DuplicateTicketException("A ticket with the same title and issue details already exists.");
        }
        ticket.setCreatedDate(LocalDate.now());
        return ticketRepo.save(ticket);
    }

    /**
     * Retrieves a ticket by its unique ID.
     *
     * @param ticketId The ID of the ticket to retrieve.
     * @return The ticket entity if found, or null otherwise.
     * @throws EntityNotFoundException if the ticket with the specified ID is not found.
     */
    @Override
    public Ticket getTicketById(Long ticketId) {
        Ticket obj = ticketRepo.findById(ticketId).orElse(null);
        if (obj != null) {
            return obj;
        }
        throw new EntityNotFoundException("Id not found");
    }

    /**
     * Retrieves all tickets from the system.
     *
     * @return A list of all ticket entities.
     */
    @Override
    public List<Ticket> gettAllTickets() {
        return ticketRepo.findAll();
    }

    /**
     * Updates an existing ticket by ID.
     *
     * @param ticketId The ID of the ticket to update.
     * @param newTicket The ticket entity containing updated details.
     * @return The updated ticket entity if found, or null otherwise.
     */
    @Override
    public Ticket updateTicket(Long ticketId, Ticket newTicket) {
        Ticket existingTicket = ticketRepo.findById(ticketId).orElse(null);
        if (existingTicket == null) {
            return null;
        } else {
            if (newTicket.getTitle() != null)
                existingTicket.setTitle(newTicket.getTitle());
            if (newTicket.getDescription() != null)
                existingTicket.setDescription(newTicket.getDescription());
            if (newTicket.getPriority() != null)
                existingTicket.setPriority(newTicket.getPriority());
            if (newTicket.getStatus() != null)
                existingTicket.setStatus(newTicket.getStatus());
            if (newTicket.getResolutionSummary() != null)
                existingTicket.setResolutionSummary(newTicket.getResolutionSummary());
            if (newTicket.getSatisfied() != null)
                existingTicket.setSatisfied(newTicket.getSatisfied());
            if (newTicket.getResolutionDate() != null)
                existingTicket.setResolutionDate(newTicket.getResolutionDate());
            if (newTicket.getSupportAgent() != null)
                existingTicket.setSupportAgent(newTicket.getSupportAgent());

            System.out.print("\nExisting ticket, after update: " + existingTicket + "\n");
            return ticketRepo.save(existingTicket);
        }
    }

    /**
     * Deletes a ticket by its unique ID.
     *
     * @param ticketId The ID of the ticket to delete.
     * @return The deleted ticket entity if found, or null otherwise.
     * @throws TicketDeletionException if the ticket with the specified ID is not found.
     */
    @Override
    public Ticket deleteTicket(Long ticketId) {
        Ticket obj = ticketRepo.findById(ticketId).orElse(null);
        if (obj != null) {
            ticketRepo.deleteById(ticketId);
            return obj;
        }
        throw new TicketDeletionException("Ticket with id not found");
    }

    /**
     * Retrieves tickets by the user ID.
     *
     * @param userId The ID of the user whose tickets to retrieve.
     * @return A list of ticket entities associated with the given user ID.
     * @throws EntityNotFoundException if the user with the specified ID is not found.
     */
    @Override
    public List<Ticket> getTicketsByUserId(Long userId) {
        User obj = userServiceImpl.getUserById(userId);
        if (obj == null) {
            throw new EntityNotFoundException("User with ID:" + userId + "Not found");
        }
        return ticketRepo.findByUser(obj);
    }

    /**
     * Retrieves tickets by the agent ID.
     *
     * @param agentId The ID of the agent whose tickets to retrieve.
     * @return A list of ticket entities associated with the given agent ID.
     * @throws EntityNotFoundException if the support agent with the specified ID is not found.
     */
    @Override
    public List<Ticket> getTicketsByAgentId(Long agentId) {
        SupportAgent obj = supportAgentServiceImpl.getSupportAgentById(agentId).orElse(null);
        if (obj == null) {
            throw new EntityNotFoundException("Agent with Id: " + agentId + " not found");
        }
        return ticketRepo.findBySupportAgent(obj);
    }

}
