/* Package declaration */
package com.examly.springapp.exceptions;

/* Importing necessary classes */
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

/* Defining this class as a global exception handler */
@ControllerAdvice
public class GlobalExceptionHandler { /* Defining the GlobalExceptionHandler class */
  
    /* Handling DuplicateAgentException */
    @ExceptionHandler(DuplicateAgentException.class)
    public ResponseEntity<String> handleDuplicateAgent(DuplicateAgentException e){
        /* Logging the exception message */
        System.out.println("Handling DuplicateAgentException: " + e.getMessage());
        
        /* Returning a 409 Conflict response with the exception message */
        return ResponseEntity.status(409).body(e.getMessage());
    }
    
    /* Handling AgentDeletionException */
    @ExceptionHandler(AgentDeletionException.class)
    public ResponseEntity<String> handleAgentDeletion(AgentDeletionException e){
        /* Logging the exception message */
        // System.out.println("Handling AgentDeletionException: " + e.getMessage());
        
        /* Returning a 409 Not Found response with the exception message */
        return ResponseEntity.status(409).body(e.getMessage());
    }

    /* Handling DuplicateTicketException */
    @ExceptionHandler(DuplicateTicketException.class)
    public ResponseEntity<String> handleDuplicateTicket(DuplicateTicketException e){
        /* Logging the exception message */
        System.out.println("Handling DuplicateTicketException: " + e.getMessage());
        
        /* Returning a 409 Conflict response with the exception message */
        return ResponseEntity.status(409).body(e.getMessage());
    }

    /* Handling TicketDeletionException */
    @ExceptionHandler(TicketDeletionException.class)
    public ResponseEntity<String> handelTicketDeletionException(TicketDeletionException e){
        /* Logging the exception message */
        System.out.println("Handling TicketDeletionException: " + e.getMessage());
        
        /* Returning a 404 Not Found response with the exception message */
        return ResponseEntity.status(404).body(e.getMessage());
    }

    /* Handling EntityNotFoundException */
    @ExceptionHandler(EntityNotFoundException.class)
    public ResponseEntity<String> handleInvalidCredentials(EntityNotFoundException e){
        /* Logging the exception message */
        System.out.println("Handling EntityNotFoundException: " + e.getMessage());
        
        /* Returning a 409 Conflict response with the exception message */
        return ResponseEntity.status(409).body(e.getMessage());
    }
    
    /* Handling DuplicateUserException */
    @ExceptionHandler(DuplicateUserException.class)
    public ResponseEntity<String> handleDuplicateUser(DuplicateUserException e){
        /* Logging the exception message */
        System.out.println("Handling DuplicateUserException: " + e.getMessage());
        
        /* Returning a 409 Conflict response with the exception message */
        return ResponseEntity.status(409).body(e.getMessage());
    }
    
    /* Handling InvalidCredentiealsException */
    @ExceptionHandler(InvalidCredentiealsException.class)
    public ResponseEntity<String> handleInvalidCredentials(InvalidCredentiealsException e){
        /* Logging the exception message */
        System.out.println("Handling InvalidCredentiealsException: " + e.getMessage());
        
        /* Returning a 401 Unauthorized response with the exception message */
        return ResponseEntity.status(401).body(e.getMessage());
    }

} /* End of GlobalExceptionHandler class */
