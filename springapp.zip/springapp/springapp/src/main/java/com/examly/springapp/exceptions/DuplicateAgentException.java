package com.examly.springapp.exceptions;


/**
 * This exception is thrown when a duplicate agent is encountered.
 */
public class DuplicateAgentException extends RuntimeException {

    /**
     * Constructs a new exception with {@code null} as its detail message.
     */
    public DuplicateAgentException() {
        super();
    }

    /**
     * Constructs a new exception with the specified detail message.
     *
     * @param message the detail message.
     */
    public DuplicateAgentException(String message) {
        super(message);
    }
    
}
