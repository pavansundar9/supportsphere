package com.examly.springapp.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Om Pathare
 * Represents a user entity in the system.
 * 
 * Provides details about the user, including personal information and roles.
 */
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long userId; // Unique identifier for each user.
    
    private String email; // The email address of the user.
    private String password; // The password for the user's account.
    private String username; // The username of the user.
    private String mobileNumber; // The mobile number of the user.
    private String userRole; // The role of the user (e.g., admin, customer).
}
