package com.examly.springapp.exceptions;

/**
 * This exception is thrown when a duplicate user is encountered.
 */
public class DuplicateUserException extends RuntimeException{

    /**
     * Constructs a new exception with {@code null} as its detail message.
     */
    public DuplicateUserException(){

    }

    /**
     * Constructs a new exception with the specified detail message.
     *
     * @param message the detail message.
     */
    public DuplicateUserException(String message){
        super(message);
    }
    
}
