package com.examly.springapp.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Om Pathare
 * Data Transfer Object (DTO) for login-related information.
 * 
 * Encapsulates login data including token, username, user role, and user ID.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginDTO {
    
    private String token; // The authentication token for the logged-in user.
    private String username; // The username of the logged-in user.
    private String userRole; // The role of the logged-in user (e.g., admin, user).
    private Long userId; // The unique identifier of the logged-in user.
}
