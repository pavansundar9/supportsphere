package com.examly.springapp.service;

import com.examly.springapp.model.User;

/**
 * @author Pavan
 * Service interface for managing user-related operations.
 * 
 * Defines the contract for the `UserServiceImpl` class, providing methods for user creation and login operations.
 */
public interface UserService {

    /**
     * Creates a new user in the system.
     *
     * @param user the `User` entity to be created.
     * @return the created `User` entity.
     */
    User createUser(User user);

    /**
     * Logs in a user to the system.
     *
     * @param user the `User` entity with login credentials.
     * @return the `User` entity if login is successful, or `null` otherwise.
     */
    User loginUser(User user);
}
