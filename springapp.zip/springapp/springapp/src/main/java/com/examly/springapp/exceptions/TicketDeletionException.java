package com.examly.springapp.exceptions;

/**
 * This exception is thrown when a ticket cannot be deleted.
 */
public class TicketDeletionException extends RuntimeException {

    /**
     * Constructs a new exception with {@code null} as its detail message.
     */
    public TicketDeletionException() {
        super();
    }

    /**
     * Constructs a new exception with the specified detail message.
     *
     * @param message the detail message.
     */
    public TicketDeletionException(String message) {
        super(message);
    }
}
