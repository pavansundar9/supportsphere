package com.examly.springapp.exceptions;

/**
 * This exception is thrown when invalid credentials are posted
 */
public class EntityNotFoundException extends RuntimeException{

    /**
     * Constructs a new exception with {@code null} as its detail message.
     */
    public EntityNotFoundException(){

    }

    /**
     * Constructs a new exception with the specified detail message.
     *
     * @param message the detail message.
     */
    public EntityNotFoundException(String message){
        super(message);
    }
}
