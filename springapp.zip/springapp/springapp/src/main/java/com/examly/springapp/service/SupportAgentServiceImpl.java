package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.exceptions.AgentDeletionException;
import com.examly.springapp.exceptions.DuplicateAgentException;
import com.examly.springapp.exceptions.EntityNotFoundException;
import com.examly.springapp.model.Feedback;
import com.examly.springapp.model.SupportAgent;
import com.examly.springapp.model.Ticket;
import com.examly.springapp.repository.FeedbackRepo;
import com.examly.springapp.repository.SupportAgentRepo;
import com.examly.springapp.repository.TicketRepo;

import jakarta.transaction.Transactional;

/**
 * @author Sravani
 * @class SupportAgentServiceImpl
 *        Service implementation for managing support agent-related operations.
 * 
 *        Annotated with `@Service` to indicate it's a Spring service class.
 *        Implements the `SupportAgentService` interface to provide specific
 *        business logic.
 */
@Service
public class SupportAgentServiceImpl implements SupportAgentService {

    private static final String AGENT_NOT_FOUND = "Support Agent with id ";
    private static final String EMAIL_EXISTS = "Support Agent with the same email already exists.";
    private static final String CANT_DELETE_AGENT = "Cannot delete Support Agent with id ";


    /**
     * Repository for managing `SupportAgent` entity data access.
     * Annotated with `@Autowired` to inject the `SupportAgentRepo` bean.
     */
    @Autowired
    private SupportAgentRepo supportAgentRepo;

    @Autowired
    private TicketRepo ticketRepo;

    @Autowired
    private FeedbackRepo feedbackRepo;

    /**
     * Adds a new support agent to the system.
     *
     * @param supportAgent The support agent entity to be added.
     * @return The added support agent entity.
     * @throws DuplicateAgentException if a support agent with the same email
     *                                 already exists.
     */
    @Override
    public SupportAgent addSupportAgent(SupportAgent supportAgent) {
        SupportAgent isExistingEmail = supportAgentRepo.findByEmail(supportAgent.getEmail());
        if (isExistingEmail != null) {
            throw new DuplicateAgentException(EMAIL_EXISTS);
        }
        supportAgent.setStatus("Available");
        return supportAgentRepo.save(supportAgent);
    }

    /**
     * Retrieves a support agent by their unique ID.
     *
     * @param agentId The ID of the support agent to retrieve.
     * @return An Optional containing the support agent entity if found, or
     *         Optional.empty() otherwise.
     * @throws EntityNotFoundException if the support agent with the specified ID is
     *                                 not found.
     */
    @Override
    public Optional<SupportAgent> getSupportAgentById(Long agentId) {
        Optional<SupportAgent> supportAgent = supportAgentRepo.findById(agentId);
        if (!supportAgent.isPresent()) {
            throw new EntityNotFoundException(AGENT_NOT_FOUND + agentId + " not found.");
        }
        return supportAgent;
    }

    /**
     * Retrieves all support agents from the system.
     *
     * @return A list of all support agent entities.
     */
    @Override
    public List<SupportAgent> getAllSupportAgents() {
        return supportAgentRepo.findAll();
    }

    /**
     * Updates an existing support agent by ID.
     *
     * @param agentId      The ID of the support agent to update.
     * @param supportAgent The support agent entity containing updated details.
     * @return The updated support agent entity if found, or null otherwise.
     * @throws EntityNotFoundException if the support agent with the specified ID is
     *                                 not found.
     */
    @Override
    public SupportAgent updateSupportAgent(Long agentId, SupportAgent supportAgent) {
        SupportAgent existingAgent = supportAgentRepo.findById(agentId).orElse(null);
        if (existingAgent == null) {
            throw new EntityNotFoundException(AGENT_NOT_FOUND + agentId + " not found.");
        }
        if (supportAgent.getName() != null) {
            existingAgent.setName(supportAgent.getName());
        }
        if (supportAgent.getPhone() != null) {
            existingAgent.setPhone(supportAgent.getPhone());
        }
        if (supportAgent.getExpertise() != null) {
            existingAgent.setExpertise(supportAgent.getExpertise());
        }
        if (supportAgent.getExperience() != null) {
            existingAgent.setExperience(supportAgent.getExperience());
        }
        if (supportAgent.getStatus() != null) {
            existingAgent.setStatus(supportAgent.getStatus());
        }
        if (supportAgent.getAddedDate() != null) {
            existingAgent.setAddedDate(supportAgent.getAddedDate());
        }
        if (supportAgent.getEmail() != null) {
            existingAgent.setEmail(supportAgent.getEmail());
        }
        if (supportAgent.getProfile() != null) {
            existingAgent.setProfile(supportAgent.getProfile());
        }
        if (supportAgent.getRemarks() != null) {
            existingAgent.setRemarks(supportAgent.getRemarks());
        }
        if (supportAgent.getShiftTiming() != null) {
            existingAgent.setShiftTiming(supportAgent.getShiftTiming());
        }
        return supportAgentRepo.save(existingAgent);
    }

    /**
     * Deletes a support agent by their unique ID.
     *
     * @param agentId The ID of the support agent to delete.
     * @return The deleted support agent entity if found, or null otherwise.
     * @throws EntityNotFoundException if the support agent with the specified ID is
     *                                 not found.
     */
    @Override
    @Transactional
    public SupportAgent deleteSupportAgent(Long agentId) {
        SupportAgent agent = supportAgentRepo.findById(agentId)
                .orElseThrow(() -> new EntityNotFoundException(AGENT_NOT_FOUND+ agentId + " not found."));

        // Check for related tickets
        List<Ticket> tickets = ticketRepo.findBySupportAgent(agent);
        if (!tickets.isEmpty()) {
            throw new AgentDeletionException(CANT_DELETE_AGENT + agentId + " because there are associated tickets.");
        }

        // Check for related feedbacks by agent
        List<Feedback> feedbacksByAgent = feedbackRepo.findBySupportAgent(agent);
        if (!feedbacksByAgent.isEmpty()) {
            throw new AgentDeletionException(
                    CANT_DELETE_AGENT + agentId + " because there are associated feedbacks.");
        }

        // Check for related feedbacks by ticket
        for (Ticket ticket : tickets) {
            List<Feedback> feedbacksByTicket = feedbackRepo.findByTicket(ticket);
            if (!feedbacksByTicket.isEmpty()) {
                throw new AgentDeletionException(CANT_DELETE_AGENT + agentId + " because there are associated feedbacks linked to tickets.");
            }
        }

        // If no related entities, delete the support agent
        supportAgentRepo.delete(agent);
        return agent;
    }

}
