/* Package declaration */
package com.examly.springapp.controller;

/* Importing necessary classes */
import java.util.List; /* Author: Suleman */

import org.springframework.beans.factory.annotation.Autowired; /* Author: Suleman */
import org.springframework.http.ResponseEntity; /* Author: Suleman */
import org.springframework.web.bind.annotation.DeleteMapping; /* Author: Suleman */
import org.springframework.web.bind.annotation.GetMapping; /* Author: Suleman */
import org.springframework.web.bind.annotation.PathVariable; /* Author: Suleman */
import org.springframework.web.bind.annotation.PostMapping; /* Author: Suleman */
import org.springframework.web.bind.annotation.PutMapping; /* Author: Suleman */
import org.springframework.web.bind.annotation.RequestBody; /* Author: Suleman */
import org.springframework.web.bind.annotation.RestController; /* Author: Suleman */

/* Importing Ticket model */
import com.examly.springapp.model.Ticket; /* Author: Suleman */

/* Importing TicketServiceImpl for ticket service implementation */
import com.examly.springapp.service.TicketServiceImpl; /* Author: Suleman */

/**
 * @author SULEMAN KHAN ,OM PATHARE
 * Controller class for handling ticket-related operations.
 * 
 * Annotated with `@RestController` to indicate it's a Spring REST controller.
 */
@RestController /* Author: Suleman */
public class TicketController { /* Author: Suleman */

    /**
     * Injecting TicketServiceImpl dependency.
     * Annotated with `@Autowired` to inject the `TicketServiceImpl` bean.
     */
    @Autowired
    private TicketServiceImpl ticketServiceImpl; /* Author: Suleman */

    /**
     * Endpoint for creating a ticket.
     * Handles POST requests to `/api/ticket`.
     * 
     * @param newTicket the ticket data received from the request body.
     * @return a ResponseEntity containing the created ticket and HTTP status 201 (Created),
     *         or HTTP status 409 (Conflict) if the ticket could not be created.
     */
    @PostMapping("/api/ticket")
    public ResponseEntity<Ticket> addTicket(@RequestBody Ticket newTicket) { /* Author: Suleman */
        /* Creating a new ticket using ticketServiceImpl */
        Ticket obj = ticketServiceImpl.addTicket(newTicket); /* Author: Suleman */

        if (obj != null) {
            /* Returning a 201 Created response with the created ticket */
            return ResponseEntity.status(201).body(obj); /* Author: Suleman */
        } else {
            /* Returning a 409 Conflict response if the ticket could not be created */
            return ResponseEntity.status(409).body(obj); /* Author: Suleman */
        }
    } /* Author: Suleman */

    /**
     * Endpoint for retrieving a ticket by ID.
     * Handles GET requests to `/api/ticket/{ticketId}`.
     * 
     * @param ticketId the ID of the ticket to retrieve.
     * @return a ResponseEntity containing the retrieved ticket and HTTP status 200 (OK) if found,
     *         or HTTP status 404 (Not Found) if not found.
     */
    @GetMapping("api/ticket/{ticketId}")
    public ResponseEntity<Ticket> getTicketById(@PathVariable Long ticketId) { /* Author: Suleman */
        /* Retrieving the ticket using ticketServiceImpl */
        Ticket obj = ticketServiceImpl.getTicketById(ticketId); /* Author: Suleman */
        if (obj != null) {
            /* Returning a 200 OK response with the retrieved ticket */
            return ResponseEntity.status(200).body(obj); /* Author: Suleman */
        } else {
            /* Returning a 404 Not Found response if the ticket is not found */
            return ResponseEntity.status(404).build(); /* Author: Suleman */
        }
    } /* Author: Suleman */

    /**
     * Endpoint for retrieving all tickets.
     * Handles GET requests to `/api/ticket`.
     * 
     * @return a ResponseEntity containing the list of all tickets and HTTP status 200 (OK),
     *         or HTTP status 400 (Bad Request) if no tickets are found.
     */
    @GetMapping("/api/ticket")
    public ResponseEntity<List<Ticket>> gettAllTickets() { /* Author: Suleman */
        /* Retrieving all tickets using ticketServiceImpl */
        List<Ticket> tickets = ticketServiceImpl.gettAllTickets(); /* Author: Suleman */
        if (tickets != null) {
            /* Returning a 200 OK response with the list of all tickets */
            return ResponseEntity.status(200).body(tickets); /* Author: Suleman */
        } else {
            /* Returning a 400 Bad Request response if no tickets are found */
            return ResponseEntity.status(400).build(); /* Author: Suleman */
        }
    } /* Author: Suleman */

    /**
     * Endpoint for updating a ticket by ID.
     * Handles PUT requests to `/api/ticket/{ticketId}`.
     * 
     * @param ticketId the ID of the ticket to update.
     * @param ticket the updated ticket data received from the request body.
     * @return a ResponseEntity containing the updated ticket and HTTP status 200 (OK) if found,
     *         or HTTP status 404 (Not Found) if not found.
     */
    @PutMapping("/api/ticket/{ticketId}")
    public ResponseEntity<Ticket> updateTicket(@PathVariable Long ticketId, @RequestBody Ticket ticket) { /* Author: Suleman */
        ticket.setTicketId(ticketId); // Set the ticketId from the path variable /* Author: Suleman */
        /* Updating the ticket using ticketServiceImpl */
        Ticket obj = ticketServiceImpl.updateTicket(ticketId, ticket); /* Author: Suleman */
        if (obj != null) {
            /* Returning a 200 OK response with the updated ticket */
            return ResponseEntity.status(200).body(obj); /* Author: Suleman */
        } else {
            /* Returning a 404 Not Found response if the ticket is not found */
            return ResponseEntity.status(404).build(); /* Author: Suleman */
        }
    } /* Author: Suleman */

    /**
     * Endpoint for deleting a ticket by ID.
     * Handles DELETE requests to `/api/ticket/{ticketId}`.
     * 
     * @param ticketId the ID of the ticket to delete.
     * @return a ResponseEntity containing the deleted ticket and HTTP status 200 (OK) if found,
     *         or HTTP status 404 (Not Found) if not found.
     */
    @DeleteMapping("/api/ticket/{ticketId}")
    public ResponseEntity<Ticket> deleteTicket(@PathVariable Long ticketId) { /* Author: Suleman */
        /* Deleting the ticket using ticketServiceImpl */
        Ticket obj = ticketServiceImpl.deleteTicket(ticketId); /* Author: Suleman */
        if (obj != null) {
            /* Returning a 200 OK response with the deleted ticket */
            return ResponseEntity.status(200).body(obj); /* Author: Suleman */
        } else {
            /* Returning a 404 Not Found response if the ticket is not found */
            return ResponseEntity.status(404).build(); /* Author: Suleman */
        }
    } /* Author: Suleman */

    /**
     * Endpoint for retrieving tickets by agent ID.
     * Handles GET requests to `/api/ticket/agent/{agentId}`.
     * 
     * @param agentId the ID of the agent whose tickets to retrieve.
     * @return a ResponseEntity containing the list of tickets and HTTP status 200 (OK) if found,
     *         or HTTP status 404 (Not Found) if not found.
     */
    @GetMapping("/api/ticket/agent/{agentId}")
    public ResponseEntity<List<Ticket>> getTicketByAgentId(@PathVariable Long agentId) { /* Author: Suleman */
        /* Retrieving tickets by agent ID using ticketServiceImpl */
        List<Ticket> obj = ticketServiceImpl.getTicketsByAgentId(agentId); /* Author: Suleman */
        if (obj != null) {
            /* Returning a 200 OK response with the list of tickets */
            return ResponseEntity.status(200).body(obj); /* Author: Suleman */
        }
        /* Returning a 404 Not Found response if no tickets are found */
        return ResponseEntity.status(404).build(); /* Author: Suleman */
    } /* Author: Suleman */

    /**
     * Endpoint for retrieving tickets by user ID.
     * Handles GET requests to `/api/ticket/user/{userId}`.
     * 
     * @param userId the ID of the user whose tickets to retrieve.
     * @return a ResponseEntity containing the list of tickets and HTTP status 200 (OK) if found,
     *         or HTTP status 404 (Not Found) if not found.
     */
    @GetMapping("/api/ticket/user/{userId}")
    public ResponseEntity<List<Ticket>> getTicketsByUserId(@PathVariable Long userId) { /* Author: Suleman */
        /* Retrieving tickets by user ID using ticketServiceImpl */
        List<Ticket> obj = ticketServiceImpl.getTicketsByUserId(userId); /* Author: Suleman */
        if (obj != null) {
            /* Returning a 200 OK response with the list of tickets */
            return ResponseEntity.status(200).body(obj); /* Author: Suleman */
        }
        /* Returning a 404 Not Found response if no tickets are found */
        return ResponseEntity.status(404).build(); /* Author: Suleman */
    } /* Author: Suleman */
}
