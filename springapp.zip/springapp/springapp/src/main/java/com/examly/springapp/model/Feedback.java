package com.examly.springapp.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * @author Om Pathare
 * Represents a feedback entity in the system.
 * 
 * Provides details about the feedback given by users, including associations with the user, support agent, and ticket.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Feedback {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long feedbackId; // Unique identifier for each feedback entry.
    
    private String feedbackText; // The text content of the feedback.
    private LocalDate date; // The date the feedback was given.

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user; // The user who provided the feedback.

    @ManyToOne
    @JoinColumn(name = "agent_id", nullable = true)
    private SupportAgent supportAgent; // The support agent associated with the feedback (optional).

    @ManyToOne
    @JoinColumn(name = "ticket_id", nullable = false)
    private Ticket ticket; // The ticket associated with the feedback.

    private String category; // The category of the feedback (e.g., complaint, suggestion).
    private Integer rating; // The rating given in the feedback.
}
