package com.examly.springapp.service;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Feedback;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.FeedbackRepo;

import jakarta.persistence.EntityNotFoundException;

/**
 * @author Satvik  
 * @class FeedbackServiceImpl
 * Service implementation for managing feedback-related operations.
 * 
 * Annotated with `@Service` to indicate it's a Spring service class.
 * Implements the `FeedbackService` interface to provide specific business logic.
 */
@Service
public class FeedbackServiceImpl implements FeedbackService {

    /**
     * Repository for managing `Feedback` entity data access.
     * Annotated with `@Autowired` to inject the `FeedbackRepo` bean.
     */
    @Autowired
    private FeedbackRepo feedbackRepository;

    /**
     * Service for managing user-related operations.
     * Annotated with `@Autowired` to inject the `UserServiceImpl` bean.
     */
    @Autowired
    private UserServiceImpl userServiceImpl;

    /**
     * Creates a new feedback entry in the system.
     *
     * @param feedback The feedback entity to be created.
     * @return The created feedback entity.
     */
    @Override
    public Feedback createFeedback(Feedback feedback) {
        return feedbackRepository.save(feedback);
    }

    /**
     * Retrieves feedback by its unique ID.
     *
     * @param feedbackId The ID of the feedback to retrieve.
     * @return The feedback entity if found, or null otherwise.
     */
    @Override
    public Feedback getFeedbackById(Long feedbackId) {
        return feedbackRepository.findById(feedbackId).orElse(null);
    }

    /**
     * Retrieves all feedback entries from the system.
     *
     * @return A list of all feedback entities.
     */
    @Override
    public List<Feedback> getAllFeedbacks() {
        List<Feedback> feedbacks = feedbackRepository.findAll();
        return feedbacks.isEmpty() ? Collections.emptyList() : feedbacks;
    }

    /**
     * Deletes feedback by its unique ID.
     *
     * @param feedbackId The ID of the feedback to delete.
     * @return The deleted feedback entity if found, or null otherwise.
     */
    @Override
    public Feedback deleteFeedback(Long feedbackId) {
        Feedback feedback = feedbackRepository.findById(feedbackId).orElse(null);
        if (feedback != null) {
            feedbackRepository.deleteById(feedbackId);
        }
        return feedback;
    }

    /**
     * Retrieves feedback entries by the user ID.
     *
     * @param userId The ID of the user whose feedback to retrieve.
     * @return A list of feedback entities associated with the given user ID.
     * @throws EntityNotFoundException if the user with the specified ID is not found.
     */
    public List<Feedback> getFeedbacksByUserId(Long userId) {
        User user = userServiceImpl.getUserById(userId);
        if (user == null) {
            throw new EntityNotFoundException("User with id " + userId + " not found");
        }
        return feedbackRepository.findByUser(user);
    }
}
