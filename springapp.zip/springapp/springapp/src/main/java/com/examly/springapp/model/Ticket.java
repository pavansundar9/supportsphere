package com.examly.springapp.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Om Pathare
 * Represents a ticket entity in the system.
 * 
 * Provides details about the ticket, including associations with the user and support agent.
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor 
public class Ticket {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long ticketId; // Unique identifier for each ticket.
    
    private String title; // The title of the ticket.
    private String description; // A detailed description of the issue.
    private String priority; // The priority level of the ticket (e.g., low, medium, high).
    private String status = "Open"; // The current status of the ticket (default is "Open").
    private LocalDate createdDate; // The date the ticket was created.

    @Column(nullable = true)
    private LocalDate resolutionDate; // The date the ticket was resolved (nullable).

    private String issueCategory; // The category of the issue (e.g., technical, billing).

    @Column(nullable = true)
    private String resolutionSummary; // A summary of how the issue was resolved (nullable).

    @Column(nullable = true)
    private Boolean satisfied; // Indicates if the user is satisfied with the resolution (nullable).

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id", nullable = false)
    private User user; // The user who created the ticket.

    @ManyToOne
    @JoinColumn(name = "agent_id", nullable = true)
    private SupportAgent supportAgent; // The support agent assigned to the ticket (nullable).
}
