package com.examly.springapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.examly.springapp.model.SupportAgent;
import com.examly.springapp.model.Ticket;
import com.examly.springapp.model.User;

@Repository
public interface TicketRepo  extends JpaRepository<Ticket,Long>{

    boolean existsByTitleAndDescription(String title, String issueDetails);

    List<Ticket> findByUser(User obj);

    List<Ticket> findBySupportAgent(SupportAgent obj);
    
}
