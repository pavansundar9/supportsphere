package com.examly.springapp.service;

import java.util.List;
import com.examly.springapp.model.Feedback;

/**
 * @author Satvik
 * FeedbackService interface provides methods to handle feedback operations.
 * Defines the feedback service for 'FeedbackServiceImpl' class
 */
public interface FeedbackService {

    /**
     * Creates a new feedback entry.
     * @param feedback The feedback object to be created.
     * @return The created Feedback object.
     */
    Feedback createFeedback(Feedback feedback);

    /**
     * Retrieves feedback by its unique ID.
     * @param feedbackId The ID of the feedback to be retrieved.
     * @return The Feedback object with the given ID.
     */
    Feedback getFeedbackById(Long feedbackId);

    /**
     * Retrieves all feedback entries.
     * @return A list of all Feedback objects.
     */
    List<Feedback> getAllFeedbacks();

    /**
     * Deletes feedback by its unique ID.
     * @param feedbackId The ID of the feedback to be deleted.
     * @return The deleted Feedback object.
     */
    Feedback deleteFeedback(Long feedbackId);
    
}
