package com.examly.springapp.exceptions;

/**
 * This exception is thrown when a duplicate ticket is encountered.
 */
public class DuplicateTicketException extends RuntimeException {

    /**
     * Constructs a new exception with {@code null} as its detail message.
     */
    public DuplicateTicketException() {
        super();
    }

    /**
     * Constructs a new exception with the specified detail message.
     *
     * @param message the detail message.
     */
    public DuplicateTicketException(String message) {
        super(message);
    }
}
