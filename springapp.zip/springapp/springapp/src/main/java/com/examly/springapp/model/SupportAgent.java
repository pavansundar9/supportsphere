package com.examly.springapp.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Om Pathare
 * Represents a support agent entity in the system.
 * 
 * Provides details about the support agent, including personal information, expertise, and profile.
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SupportAgent {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long agentId; // Unique identifier for each support agent.
    
    private String name; // The name of the support agent.
    private String email; // The email address of the support agent.
    private String phone; // The phone number of the support agent.
    private String expertise; // The area of expertise of the support agent.
    private String experience; // The experience level of the support agent.
    private String status; // The current status of the support agent (e.g., active, inactive).
    private LocalDate addedDate; // The date the support agent was added to the system.

    @Lob
    @Column(nullable = true, length = 100000000)
    private byte[] profile; // The profile picture of the support agent.
    
    private String shiftTiming; // The shift timing of the support agent.
    private String remarks; // Any additional remarks or comments about the support agent.   
    
}
