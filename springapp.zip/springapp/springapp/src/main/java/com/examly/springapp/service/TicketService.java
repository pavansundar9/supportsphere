package com.examly.springapp.service;
import java.util.List;
import com.examly.springapp.model.Ticket;

/**
 * @author Suleman
 * Service interface for managing ticket-related operations.
 * 
 * Defines the contract for the `TicketServiceImpl` class, providing methods for ticket CRUD operations and specific ticket queries.
 */
public interface TicketService {

    /**
     * Adds a new ticket to the system.
     *
     * @param ticket the `Ticket` entity to be added.
     * @return the added `Ticket` entity.
     */
    public Ticket addTicket(Ticket ticket);

    /**
     * Retrieves a ticket by its unique ID.
     *
     * @param ticketId the ID of the ticket to retrieve.
     * @return the `Ticket` entity if found, or `null` otherwise.
     */
    public Ticket getTicketById(Long ticketId);

    /**
     * Retrieves all tickets from the system.
     *
     * @return a list of all `Ticket` entities.
     */
    public List<Ticket> gettAllTickets();

    /**
     * Updates an existing ticket by ID.
     *
     * @param ticketId the ID of the ticket to update.
     * @param ticket the updated `Ticket` entity details.
     * @return the updated `Ticket` entity if found, or throws an exception if not found.
     */
    public Ticket updateTicket(Long ticketId, Ticket ticket);

    /**
     * Deletes a ticket by its unique ID.
     *
     * @param ticketId the ID of the ticket to delete.
     * @return the deleted `Ticket` entity.
     */
    public Ticket deleteTicket(Long ticketId);

    /**
     * Retrieves tickets by the user ID.
     *
     * @param userId the ID of the user whose tickets to retrieve.
     * @return a list of `Ticket` entities associated with the given user ID.
     */
    public List<Ticket> getTicketsByUserId(Long userId);

    /**
     * Retrieves tickets by the agent ID.
     *
     * @param agentId the ID of the agent whose tickets to retrieve.
     * @return a list of `Ticket` entities associated with the given agent ID.
     */
    public List<Ticket> getTicketsByAgentId(Long agentId);
}
