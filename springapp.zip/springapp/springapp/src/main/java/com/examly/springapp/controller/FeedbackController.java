package com.examly.springapp.controller; 
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.http.ResponseEntity; 
import org.springframework.web.bind.annotation.DeleteMapping; 
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.examly.springapp.model.Feedback;
import com.examly.springapp.service.FeedbackServiceImpl;

/**
 * @author SATVIK KUMAR, Om Pathare
 * Controller class for handling feedback-related operations.
 * 
 * Annotated with `@RestController` to indicate it's a Spring REST controller.
 * Maps requests to `/api/feedback` to this controller.
 */
@RestController
@RequestMapping("/api/feedback")
public class FeedbackController { /* Author: Satvik */

    /**
     * Injecting FeedbackServiceImpl dependency.
     * Annotated with `@Autowired` to inject the `FeedbackServiceImpl` bean.
     */
    @Autowired
    private FeedbackServiceImpl feedbackServiceImpl; /* Author: Satvik */

    /**
     * Endpoint for creating feedback.
     * Handles POST requests to `/api/feedback`.
     * 
     * @param feedback the feedback data received from the request body.
     * @return a ResponseEntity containing the created feedback and HTTP status 201 (Created).
     */
    @PostMapping
    public ResponseEntity<Feedback> createFeedback(@RequestBody Feedback feedback) { /* Author: Satvik */
        /* Logging the received feedback data */
        System.out.println("Received feedback data for creation: " + feedback); /* Author: Satvik */
        
        /* Calling createFeedback method from feedbackServiceImpl to create a new feedback */
        Feedback createdFeedback = feedbackServiceImpl.createFeedback(feedback); /* Author: Satvik */
        
        /* Logging the created feedback data */
        System.out.println("Created feedback data: " + createdFeedback); /* Author: Satvik */
        
        /* Returning a 201 Created response with the created feedback */
        return ResponseEntity.status(201).body(createdFeedback); /* Author: Satvik */
    } /* Author: Satvik */

    /**
     * Endpoint for retrieving feedback by ID.
     * Handles GET requests to `/api/feedback/{id}`.
     * 
     * @param feedbackId the ID of the feedback to retrieve.
     * @return a ResponseEntity containing the retrieved feedback and HTTP status 200 (OK) if found,
     *         or HTTP status 404 (Not Found) if not found.
     */
    @GetMapping("/{id}")
    public ResponseEntity<Feedback> getFeedbackById(@PathVariable("id") Long feedbackId) { /* Author: Satvik */
        /* Logging the received feedback ID */
        System.out.println("Received feedback ID for retrieval: " + feedbackId); /* Author: Satvik */
        
        /* Calling getFeedbackById method from feedbackServiceImpl to retrieve the feedback */
        Feedback feedback = feedbackServiceImpl.getFeedbackById(feedbackId); /* Author: Satvik */
        
        /* Logging the retrieved feedback data */
        System.out.println("Retrieved feedback data: " + feedback); /* Author: Satvik */
        
        if (feedback != null) { /* Author: Satvik */
            /* Returning a 200 OK response with the retrieved feedback */
            return ResponseEntity.status(200).body(feedback); /* Author: Satvik */
        } else { /* Author: Satvik */
            /* Returning a 404 Not Found response if feedback is not found */
            return ResponseEntity.status(404).build(); /* Author: Satvik */
        } /* Author: Satvik */
    } /* Author: Satvik */

    /**
     * Endpoint for retrieving all feedbacks.
     * Handles GET requests to `/api/feedback`.
     * 
     * @return a ResponseEntity containing the list of all feedbacks and HTTP status 200 (OK).
     */
    @GetMapping
    public ResponseEntity<List<Feedback>> getAllFeedback() { /* Author: Om Pathare */
        /* Calling getAllFeedbacks method from feedbackServiceImpl to retrieve all feedbacks */
        List<Feedback> feedbacks = feedbackServiceImpl.getAllFeedbacks(); /* Author: Satvik */
        
        /* Logging the retrieved feedback list */
        System.out.println("Retrieved all feedbacks: " + feedbacks); /* Author: Satvik */
        
        /* Returning a 200 OK response with the list of all feedbacks */
        return ResponseEntity.status(200).body(feedbacks); /* Author: Satvik */
    } /* Author: Satvik */
  
    /**
     * Endpoint for retrieving feedbacks by user ID.
     * Handles GET requests to `/api/feedback/user/{userId}`.
     * 
     * @param userId the ID of the user whose feedbacks to retrieve.
     * @return a ResponseEntity containing the list of feedbacks for the user and HTTP status 200 (OK) if found,
     *         or HTTP status 204 (No Content) if no feedbacks are found.
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Feedback>> getFeedbacksByUserId(@PathVariable("userId") Long userId) { /* Author: Satvik */
        /* Logging the received user ID */
        System.out.println("Received user ID for feedback retrieval: " + userId); /* Author: Satvik */
        
        /* Calling getFeedbacksByUserId method from feedbackServiceImpl to retrieve feedbacks by user ID */
        List<Feedback> feedbacks = feedbackServiceImpl.getFeedbacksByUserId(userId); /* Author: Satvik */
        
        /* Logging the retrieved feedback list */
        System.out.println("Retrieved feedbacks for user ID " + userId + ": " + feedbacks); /* Author: Satvik */
        
        if (feedbacks.isEmpty()) { /* Author: Satvik */
            /* Returning a 204 No Content response if no feedbacks are found */
            return ResponseEntity.status(204).build(); /* Author: Satvik */
        } else { /* Author: Satvik */
            /* Returning a 200 OK response with the list of feedbacks for the user */
            return ResponseEntity.status(200).body(feedbacks); /* Author: Satvik */
        } /* Author: Satvik */
    } /* Author: Satvik */
  
    /**
     * Endpoint for deleting feedback by ID.
     * Handles DELETE requests to `/api/feedback/{id}`.
     * 
     * @param feedbackId the ID of the feedback to delete.
     * @return a ResponseEntity containing the deleted feedback and HTTP status 200 (OK) if found,
     *         or HTTP status 404 (Not Found) if not found.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Feedback> deleteFeedback(@PathVariable("id") Long feedbackId) { /* Author: Satvik */
        /* Logging the received feedback ID for deletion */
        System.out.println("Received feedback ID for deletion: " + feedbackId); /* Author: Satvik */
        
        /* Calling deleteFeedback method from feedbackServiceImpl to delete the feedback */
        Feedback deletedFeedback = feedbackServiceImpl.deleteFeedback(feedbackId); /* Author: Satvik */
        
        /* Logging the deleted feedback data */
        System.out.println("Deleted feedback data: " + deletedFeedback); /* Author: Satvik */
        
        if (deletedFeedback != null) { /* Author: Satvik */
            /* Returning a 200 OK response with the deleted feedback */
            return ResponseEntity.status(200).body(deletedFeedback); /* Author: Satvik */
        } else { /* Author: Satvik */
            /* Returning a 404 Not Found response if feedback is not found */
            return ResponseEntity.status(404).build(); /* Author: Satvik */
        } /* Author: Satvik */
    } /* Author: Satvik */
} /* Author: Satvik */
