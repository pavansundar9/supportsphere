package com.examly.springapp.service;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Feedback;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.FeedbackRepo;

import jakarta.persistence.EntityNotFoundException;

@Service
public class FeedbackServiceImpl implements FeedbackService {

    @Autowired
    private FeedbackRepo feedbackRepository;

    @Autowired
    private UserServiceImpl userServiceImpl;

    @Override
    public Feedback createFeedback(Feedback feedback) {
        return feedbackRepository.save(feedback);
    }

    @Override
    public Feedback getFeedbackById(Long feedbackId) {
        Feedback feedback = feedbackRepository.findById(feedbackId).orElse(null);
        return feedback;
    }

    @Override
    public List<Feedback> getAllFeedbacks() {
        List<Feedback> feedbacks = feedbackRepository.findAll();


        return feedbacks.isEmpty() ? Collections.emptyList() : feedbacks;
    }

    @Override
    public Feedback deleteFeedback(Long feedbackId) {
        Feedback feedback = feedbackRepository.findById(feedbackId).orElse(null);
        if (feedback != null) {
            feedbackRepository.deleteById(feedbackId);
        }
        return feedback;
    }

    public List<Feedback> getFeedbacksByUserId(Long userId) {
        // Fetch the User object by userId
        User user = userServiceImpl.getUserById(userId);
        if (user == null) {
            throw new EntityNotFoundException("User with id " + userId + " not found");
        }
        return feedbackRepository.findByUser(user);
    }
}

