package com.examly.springapp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.SupportAgent;
import com.examly.springapp.service.SupportAgentServiceImpl;

@RestController
public class SupportAgentController {

    @Autowired
    private SupportAgentServiceImpl supportAgentServiceImpl;

    @PostMapping("/api/supportAgent")
    public ResponseEntity<SupportAgent> addSupportAgent(@RequestBody SupportAgent supportAgent) {
        return ResponseEntity.status(201).body(supportAgentServiceImpl.addSupportAgent(supportAgent));
    }

    @GetMapping("/api/supportAgent")
    public ResponseEntity<List<SupportAgent>> getAllSupportAgents() {
        List<SupportAgent> supportAgents = supportAgentServiceImpl.getAllSupportAgents();
        if (supportAgents.size() > 0) {
            return ResponseEntity.status(200).body(supportAgents);
        }
        return ResponseEntity.status(204).build();
        
    }

    @GetMapping("/api/supportAgent/{agentId}")
    public ResponseEntity<SupportAgent> getSupportAgent(@PathVariable Long agentId) {
        Optional<SupportAgent> supportAgent = supportAgentServiceImpl.getSupportAgentById(agentId);

        if (supportAgent.isPresent()) {
            return ResponseEntity.status(200).body(supportAgent.get());
        } else {
            return ResponseEntity.status(404).build();
        }
    }
    @PutMapping("/api/supportAgent/{agentId}")
    public ResponseEntity<SupportAgent> updateSupportAgent(@PathVariable Long agentId,@RequestBody SupportAgent supportAgent){
        supportAgent=supportAgentServiceImpl.updateSupportAgent(agentId, supportAgent);
       if(supportAgent!=null){
        return ResponseEntity.status(200).body(supportAgent);
       }
       else{
        return ResponseEntity.status(404).build();
       }
    }

    @DeleteMapping("/api/supportAgent/{agentId}")
    public ResponseEntity<SupportAgent> deleteSupportAgent(@PathVariable Long agentId){
        SupportAgent supportAgent=supportAgentServiceImpl.deleteSupportAgent(agentId);
        // if(supportAgent==null){
        //     return ResponseEntity.status(404).build();

        // }
        return ResponseEntity.status(200).body(supportAgent);
    }

}
