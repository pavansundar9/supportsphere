package com.examly.springapp.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SupportAgent {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long agentId;
    private String name;
    private String email;
    private String phone;
    private String expertise;
    private String experience;
    private String status;
    private LocalDate addedDate;

    @Lob
    @Column(nullable = true)
    private String profile;
    private String shiftTiming;
    private String remarks;
}
