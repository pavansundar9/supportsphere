package com.examly.springapp.exceptions;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
  
    @ExceptionHandler(DuplicateAgentException.class)
    public ResponseEntity<String> handleDuplicateAgent(DuplicateAgentException e){
        return ResponseEntity.status(409).body(e.getMessage());
    }
    
    @ExceptionHandler(AgentDeletionException.class)
    public ResponseEntity<String>handleAgentDeletion(AgentDeletionException e){
        return ResponseEntity.status(404).body(e.getMessage());
    }

    @ExceptionHandler(DuplicateTicketException.class)
    public ResponseEntity<String> handleDuplicateTicket(DuplicateTicketException e){
        return ResponseEntity.status(409).body(e.getMessage());
    }

    @ExceptionHandler(TicketDeletionException.class)
    public ResponseEntity<String> handelTicketDeletionException(TicketDeletionException e){
        return ResponseEntity.status(404).body(e.getMessage());
    }

    @ExceptionHandler(EntityNotFoundException.class)
    public ResponseEntity<String> handleInvalidCredentials(EntityNotFoundException e){
        return ResponseEntity.status(409).body(e.getMessage());
    }
    
    @ExceptionHandler(DuplicateUserException.class)
    public ResponseEntity<String> handleDuplicateUser(DuplicateUserException e){
        return ResponseEntity.status(409).body(e.getMessage());
    }
    
    @ExceptionHandler(InvalidCredentiealsException.class)
    public ResponseEntity<String> handleInvalidCredentials(InvalidCredentiealsException e){
        return ResponseEntity.status(401).body(e.getMessage());
    }

}

