package com.examly.springapp.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor 
public class Ticket {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long ticketId;
    private String title;
    private String description;
    private String priority; 
    private String status = "Open";
    private LocalDate createdDate;

    @Column(nullable = true)
    private LocalDate resolutionDate;
    private String issueCategory;

    @Column(nullable = true)
    private String resolutionSummary;

    @Column(nullable = true)
    private Boolean satisfied;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id" , nullable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "agent_id" , nullable = true )
    private SupportAgent supportAgent;
}
