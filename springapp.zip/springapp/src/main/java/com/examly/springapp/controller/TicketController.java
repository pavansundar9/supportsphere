package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.Ticket;
import com.examly.springapp.service.TicketServiceImpl;

@RestController
public class TicketController {

    @Autowired
    private TicketServiceImpl ticketServiceImpl;

    // 1.
    @PostMapping("/api/ticket")
    public ResponseEntity<Ticket> addTicket(@RequestBody Ticket newTicket) {
        Ticket obj = ticketServiceImpl.addTicket(newTicket);
        if (obj != null) {
            return ResponseEntity.status(201).body(obj);
        } else {
            return ResponseEntity.status(409).body(obj);

        }
    }

    // 2.
    @GetMapping("api/ticket/{ticketId}")
    public ResponseEntity<Ticket> getTicketById(@PathVariable Long ticketId) {
        Ticket obj = ticketServiceImpl.getTicketById(ticketId);
        if (obj != null) {
            return ResponseEntity.status(200).body(obj);
        } else {
            return ResponseEntity.status(404).build();
        }
    }

    // 3.
    @GetMapping("/api/ticket")
    public ResponseEntity<List<Ticket>> gettAllTickets() {
        List<Ticket> tickets = ticketServiceImpl.gettAllTickets();
        if (tickets != null) {
            return ResponseEntity.status(200).body(tickets);
        } else {
            return ResponseEntity.status(400).build();
        }
    }

    // 4.
    @PutMapping("/api/ticket/{ticketId}")
    public ResponseEntity<Ticket> updateTicket(@PathVariable Long ticketId, @RequestBody Ticket ticket) {
        Ticket obj = ticketServiceImpl.updateTicket(ticketId, ticket);
        if (obj != null) {
            return ResponseEntity.status(200).body(obj);
        } else {
            return ResponseEntity.status(404).build();
        }
    }

    // 5.
    @DeleteMapping("/api/ticket/{ticketId}")
    public ResponseEntity<Ticket> deleteTicket(@PathVariable Long ticketId) {
        Ticket obj = ticketServiceImpl.deleteTicket(ticketId);
        if (obj != null) {
            return ResponseEntity.status(200).body(obj);
        } else {
            return ResponseEntity.status(404).build();
        }
    }

    // 6.
    @GetMapping("/api/ticket/agent/{agentId}")
    public ResponseEntity<List<Ticket>> getTicketByAgentId(@PathVariable Long agentId) {
        List<Ticket> obj = ticketServiceImpl.getTicketsByAgentId(agentId);
        if (obj != null) {
            return ResponseEntity.status(200).body(obj);
        }
        return ResponseEntity.status(404).build();
    }

    // 7.
    @GetMapping("/api/ticket/user/{userId}")
    public ResponseEntity<List<Ticket>> getTicketsByUserId(@PathVariable Long userId) {
        List<Ticket> obj = ticketServiceImpl.getTicketsByUserId(userId);
        if (obj != null) {
            return ResponseEntity.status(200).body(obj);
        }
        return ResponseEntity.status(404).build();
    }

}