package com.examly.springapp.exceptions;

public class InvalidCredentiealsException extends RuntimeException{
    public InvalidCredentiealsException(String msg){
        super(msg);
    }
}
