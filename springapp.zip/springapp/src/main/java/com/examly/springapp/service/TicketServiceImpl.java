package com.examly.springapp.service;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.batch.BatchProperties.Job;
import org.springframework.stereotype.Service;

import com.examly.springapp.exceptions.DuplicateTicketException;
import com.examly.springapp.exceptions.EntityNotFoundException;
import com.examly.springapp.exceptions.TicketDeletionException;
import com.examly.springapp.model.SupportAgent;
import com.examly.springapp.model.Ticket;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.TicketRepo;

@Service
public class TicketServiceImpl implements TicketService {

    @Autowired
    private TicketRepo ticketRepo;

    @Autowired
    private UserServiceImpl userServiceImpl;

    @Autowired
    private SupportAgentServiceImpl supportAgentServiceImpl;

    @Override
    // 1.
    public Ticket addTicket(Ticket ticket) {
        if (ticketRepo.existsByTitleAndDescription(ticket.getTitle(), ticket.getDescription())) {
            throw new DuplicateTicketException("A ticket with the same title and issue details already exists.");
        }
        ticket.setCreatedDate(LocalDate.now());
        return ticketRepo.save(ticket);
    }

    @Override
    // 2.
    public Ticket getTicketById(Long ticketId) {
        Ticket obj = ticketRepo.findById(ticketId).orElse(null);
        if (obj != null) {
            return obj;
        }
        throw new EntityNotFoundException("Id not found");
    }

    @Override
    // 3.
    public List<Ticket> gettAllTickets() {
        return ticketRepo.findAll();
    }

    @Override

    // 4.
    public Ticket updateTicket(Long ticketId, Ticket newTicket) {
        Ticket existingTicket = ticketRepo.findById(ticketId).orElse(null);
        if (existingTicket == null) {
            return null;
        } else {
            if (newTicket.getTitle() != null)
                existingTicket.setTitle(newTicket.getTitle());
            if (newTicket.getDescription() != null)
                existingTicket.setDescription(newTicket.getDescription());
            if (newTicket.getPriority() != null)
                existingTicket.setPriority(newTicket.getPriority());
            if (newTicket.getStatus() != null)
                existingTicket.setStatus(newTicket.getStatus());
            if(newTicket.getUser()!=null)
                existingTicket.setUser(newTicket.getUser());
            return ticketRepo.save(existingTicket);
        }
    }

    @Override
    // 5.
    public Ticket deleteTicket(Long ticketId) {
        Ticket obj = ticketRepo.findById(ticketId).orElse(null);

        if (obj != null) {
            ticketRepo.deleteById(ticketId);
            return obj;
        }
        throw new TicketDeletionException("Ticket with id not found");
    }

    @Override
    // 6.
    public List<Ticket> getTicketsByUserId(Long userId) {
        User obj = userServiceImpl.getUserById(userId);
        if(obj==null){
            throw new EntityNotFoundException("User with ID:"+ userId+"Not found");
        }
        List<Ticket> obj2 = ticketRepo.findByUser(obj);
        return obj2;
    }

    @Override
    // 7.
    public List<Ticket> getTicketsByAgentId(Long agentId) {
        SupportAgent obj = supportAgentServiceImpl.getSupportAgentById(agentId).orElse(null);
        if(obj==null){
            throw new EntityNotFoundException("Agent with Id: "+agentId+" not found");
        }
        List<Ticket> obj2 = ticketRepo.findBySupportAgent(obj);
        return obj2;
    }

}
