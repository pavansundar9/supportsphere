package com.examly.springapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.examly.springapp.exceptions.EntityNotFoundException;
import com.examly.springapp.exceptions.InvalidCredentiealsException;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.UserRepo;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public User createUser(User user) {
        if(userRepo.findByUsername(user.getUsername()).isPresent() ||
            userRepo.findByEmail(user.getEmail()).isPresent()){
                throw new EntityNotFoundException("A user with this email already exists");
            }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepo.save(user);
    }

    @Override
    public User loginUser(User user) {
        User existingUser = userRepo.findByUsername(user.getUsername())
                .orElseThrow(() -> new InvalidCredentiealsException("Invalid user name or password."));

        if (!passwordEncoder.matches(user.getPassword(), existingUser.getPassword())) {
            throw new InvalidCredentiealsException("Invalid user name or password.");
        }
        return existingUser;
    }
    
    public User getUserById(Long userId){
        User existingUser = userRepo.findById(userId).orElse(null);
        if (existingUser!=null) {
            existingUser.setPassword(null);
        }
        return existingUser;
    }

    public User getByUserName(String username){
        return userRepo.findByUsername(username).orElse(null);
    }
}
