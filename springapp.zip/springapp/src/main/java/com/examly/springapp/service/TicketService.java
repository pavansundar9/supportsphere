package com.examly.springapp.service;

import java.lang.StackWalker.Option;
import java.util.List;

import com.examly.springapp.model.Ticket;

public interface TicketService  {

    public Ticket addTicket(Ticket ticket);
    public Ticket getTicketById(Long ticketId);
    public List<Ticket> gettAllTickets();
    public Ticket updateTicket(Long ticketId,Ticket ticket);
    public Ticket deleteTicket(Long ticketId);
    public List<Ticket> getTicketsByUserId(Long userId);
    public List<Ticket> getTicketsByAgentId(Long agentId);
   
    
}
