package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.exceptions.AgentDeletionException;
import com.examly.springapp.exceptions.DuplicateAgentException;
import com.examly.springapp.exceptions.EntityNotFoundException;
import com.examly.springapp.model.SupportAgent;
import com.examly.springapp.repository.SupportAgentRepo;



@Service
public class SupportAgentServiceImpl implements SupportAgentService {

    @Autowired
    private SupportAgentRepo supportAgentRepo;

    @Override
    public SupportAgent addSupportAgent(SupportAgent supportAgent) {
        SupportAgent isExistingEmail = supportAgentRepo.findByEmail(supportAgent.getEmail());
        System.out.print("\n" + isExistingEmail + "\n");

        if (isExistingEmail != null) {
            throw new DuplicateAgentException("Support Agent with the same email already exits.");
        }

        return supportAgentRepo.save(supportAgent);
    }

    @Override
    public Optional<SupportAgent> getSupportAgentById(Long agentId) {
        Optional<SupportAgent> supportAgent = supportAgentRepo.findById(agentId);
        if (supportAgent == null) {
            throw new EntityNotFoundException("Support Agnet with id "+agentId+" not found");
        }
        return supportAgent;
    }

    @Override
    public List<SupportAgent> getAllSupportAgents() {
        return supportAgentRepo.findAll();
    }

    @Override
    public SupportAgent updateSupportAgent(Long agentId, SupportAgent supportAgent) {
        SupportAgent existingAgent = supportAgentRepo.findById(agentId).orElse(null);
        if (existingAgent == null) {
            throw new EntityNotFoundException("Support Agent with ID " + agentId + " not found");
        }
        if (supportAgent.getName() != null) {
            existingAgent.setName(supportAgent.getName());
        }
        if (supportAgent.getPhone() != null) {
            existingAgent.setPhone(supportAgent.getPhone());
        }
        if (supportAgent.getExpertise() != null) {
            existingAgent.setExpertise(supportAgent.getExpertise());
        }
        if (supportAgent.getExperience() != null) {
            existingAgent.setExperience(supportAgent.getExperience());
        }
        if (supportAgent.getStatus() != null) {
            existingAgent.setStatus(supportAgent.getStatus());
        }
        if (supportAgent.getAddedDate() != null) {
            existingAgent.setAddedDate(supportAgent.getAddedDate());
        }
        return supportAgentRepo.save(existingAgent);
    }

    @Override
    public SupportAgent deleteSupportAgent(Long agentId) {
        SupportAgent obj = supportAgentRepo.findById(agentId).orElse(null);

        if (obj != null) {
            supportAgentRepo.deleteById(agentId);
            return obj;
        }
        throw new AgentDeletionException("Agent with ID " + agentId + " not found");
    }

}
