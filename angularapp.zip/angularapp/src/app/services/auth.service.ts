import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { User } from '../models/user.model';
import { Login } from '../models/login.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
// import { default as jwt_decode } from 'jwt-decode';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private readonly apiUrl = `https://8080-fdbcbebcaabbfaebfdaffddeddbeccdd.premiumproject.examly.io/api`; // Replace with your backend API URL

  private userRoleSubject = new BehaviorSubject<string | null>(null);  
  private usernameSubject = new BehaviorSubject<string | null>(null);
  private userIdSubject = new BehaviorSubject<string | null>(null);

  constructor(private http: HttpClient) { }

  register(user: User): Observable<any> {
    return this.http.post(`${this.apiUrl}/register`, user);
  }

  login(login: Login): Observable<any> {
    return this.http.post<{ token: string, username: string, userRole: string, userId: number }>(`${this.apiUrl}/login`, login)
      .pipe(map(response => {
        this.setAuthToken(response.token);
        this.updateUserDetails(response);
        return response;
      }));
  }

  private setAuthToken(token: string): void {
    localStorage.setItem('authToken', token);
    // this.decodeToken(token);
  }

  private updateUserDetails(response: { token: string, username: string, userRole: string, userId: number }): void {
    this.userRoleSubject.next(response.userRole);
    this.userIdSubject.next(response.userId.toString());
    this.usernameSubject.next(response.username.toString());
  }

  // private decodeToken(token: string): void {
  //   const decoded: any = jwt_decode(token);
  //   this.userRoleSubject.next(decoded.userRole);
  //   this.usernameSubject.next(decoded.username);
  // }

  getAuthToken(): string | null {
    return localStorage.getItem('authToken');
  }

  getAuthHeaders(): HttpHeaders {
    const token = this.getAuthToken();
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  get userRole$(): Observable<string | null> {
    return this.userRoleSubject.asObservable();
  }

  get username$(): Observable<string | null> {
    return this.usernameSubject.asObservable();
  }

  get userId$(): Observable<string | null> {
    return this.userIdSubject.asObservable();
  }

  isLoggedIn(): boolean {
    return !!this.getAuthToken();
  }

  isManager(): boolean {
    return this.userRoleSubject.value?.toLowerCase() === 'manager';
  }

  isClient(): boolean {
    return this.userRoleSubject.value?.toLowerCase() === 'client';
  }
}
