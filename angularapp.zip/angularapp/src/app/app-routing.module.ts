import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { ClientnavComponent } from './components/clientnav/clientnav.component';
import { ManagernavComponent } from './components/managernav/managernav.component';

const routes: Routes = [
  {path: "login", component: LoginComponent},
  {path: "register", component: SignupComponent},
  {path: "clientnav", component: ClientnavComponent},
  {path: "managernav", component: ManagernavComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
