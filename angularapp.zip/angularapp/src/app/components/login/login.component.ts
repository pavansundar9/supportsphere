import { Component, OnInit } from '@angular/core';
import { Login } from 'src/app/models/login.model';
import { AuthService } from 'src/app/services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login: Login = new Login();

  constructor(private authService: AuthService, private router: Router) { }

  onSubmit(): void {
    this.authService.login(this.login).subscribe(response => {
      // Handle login success
      console.log('Login successful', response);
      
      // Navigate based on user role
      if (response.userRole.toLowerCase() === 'client') {
        this.router.navigate(['/clientnav']);
      } else if (response.userRole.toLowerCase() === 'manager') {
        this.router.navigate(['/managernav']);
      }

    }, error => {
      // Handle login error
      console.error('Login failed', error);
    });
  }

  ngOnInit(): void {
  }
}
