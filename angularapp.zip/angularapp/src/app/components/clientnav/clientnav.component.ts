import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-clientnav',
  templateUrl: './clientnav.component.html',
  styleUrls: ['./clientnav.component.css']
})
export class ClientnavComponent implements OnInit {

  username: string | null = '';
  role: string | null = '';
  userId: string | null = '';

  constructor(private authService: AuthService) { }

  ngOnInit(): void {
    this.authService.userRole$.subscribe(userRole => {
      this.role = userRole;
    });

    this.authService.userId$.subscribe(userId => {
      this.userId = userId;
    });

    this.authService.username$.subscribe(username => {
      this.username = username;
    });
  }
}
