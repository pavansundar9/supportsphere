import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthguardService implements CanActivate{

    constructor(private authService: AuthService, private router: Router) {}
  
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
      if (!this.authService.isLoggedIn()) {
        this.router.navigate(['/login']);
        return false;
      }
  
      const routePath = route.url[0].path;
  
      if (routePath === 'manager' && !this.authService.isManager()) {
        this.router.navigate(['/forbidden']);
        return false;
      }
  
      if (routePath === 'client' && !this.authService.isClient()) {
        this.router.navigate(['/forbidden']);
        return false;
      }
  
    }
}
