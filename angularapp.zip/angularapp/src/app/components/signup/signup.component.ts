import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  user: User = new User();

  constructor(private authService: AuthService) { }

  onSubmit(): void {
    this.authService.register(this.user).subscribe(response => {
      // Handle registration success
      console.log('Registration successful', response);
    }, error => {
      // Handle registration error
      console.error('Registration failed', error);
    });
  }

  ngOnInit(): void {
  }

}
